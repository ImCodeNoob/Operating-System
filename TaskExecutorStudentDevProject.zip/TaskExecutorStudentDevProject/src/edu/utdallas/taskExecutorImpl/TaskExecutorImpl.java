package edu.utdallas.taskExecutorImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import edu.utdallas.blockingFIFO.BlockingFIFO;
import edu.utdallas.taskExecutor.*;

public class TaskExecutorImpl implements TaskExecutor
{
  //create a blocking FIFO
  private BlockingFIFO queue = new BlockingFIFO(100);
  
  // get current working directory
  private String dir = System.getProperty("user.dir");
  
  // shared PrintWriter
  private static PrintWriter writer;
  
  // create the thread pool
  private Thread[] pool;
  
  //constructor
  public TaskExecutorImpl(int size) {
    pool = new Thread[size];
    try {
        File logFile = new File(dir.concat("/log.txt"));
        writer = new PrintWriter(logFile);
        for (int i=0;i<pool.length;i++){
            pool[i]=new Thread(new TaskRunner(),"TaskThread".concat(((Integer)i).toString()));
            pool[i].start();
        }
    }catch(Throwable e) {
        if (!(e instanceof FileNotFoundException)){
            e.printStackTrace(writer);
        }
        else{
            System.out.println("Cannot create log file");
        }
    }
}
	@Override
	public void addTask(Task task) {
		// TODO Complete the implementation
	  try {
          queue.put(task);
      }
      catch(Throwable e){
          e.printStackTrace(writer);
      }
	}
	
	private class TaskRunner implements java.lang.Runnable {
	  public void run() {
	    while(true) {
	      try {
	        Task newTask = queue.take();
	        newTask.execute();
	      }
	      catch(Throwable th) {
	        th.printStackTrace(writer);
	      }
	    }
	  }
	}
}
