package edu.utdallas.blockingFIFO;

import edu.utdallas.taskExecutor.*;

public class BlockingFIFO {
  private Task[] queue;
//monitor which monitors if FIFO is full
  private static Object notFull = new Object();
  
  // monitor which monitors if FIFO is empty
  private static Object notEmpty = new Object();
  
  // next index position for inserting a new task
  private static int nextIn = 0;
  
  // next indes position for retrieving a task in FIFO
  private static int nextOut = 0;
  
  // counter of number of tasks already in FIFO
  private static int count = 0;
  
  // counter of threads waiting to enter critical section in purpose of inserting a new task
  private static int threadCount = 0;
  
  // counter of threads currently in critical section in purpose of inserting a new task
  private static int addInBlock = 0;
  
  // counter of threads waiting to enter critical section in purpose of retrieving a existing task
  private static int threadDeCount = 0;
  
  // counter of threads currently in critical section in purpose of retrieving an existing task
  private static int takeInBlock = 0;
  
  
  // constructor
  public BlockingFIFO(int size){
      queue = new Task[size];
  }
  
  /** 
   * @literal method to take items from the FIFO
   * @return  a task retrieved from the FIFO
   * @throws  InterruptedException  if any thread interrupted the current thread before or while 
   * the current thread was waiting for a notification. The interrupted status of the current thread 
   * is cleared when this exception is thrown.
   */
  public Task take() throws InterruptedException{
      
      // if FIFO is empty, blocking all retrieving threads
      if(count == 0)
          synchronized(notEmpty){
              notEmpty.wait();
          }
      
      Task task;
      // increased because one thread arrived and waiting to enter the critical section
      threadDeCount ++;
      
      // synchronized block that take a task from FIFO and update corresponding cursors
      synchronized(this){
          takeInBlock++;
          threadDeCount--;
          task = queue[nextOut];
          nextOut = (nextOut + 1) % queue.length;
          count--;
          takeInBlock--;
      }
      
      /** 
      * threads waiting to enter critical section are candidates for inserting tasks into FIFO
      * current number of tasks in FIFO + potential tasks that will be added to FIFO in the future < FIFO size
      * This must be checked to avoid FIFO overflow.
      */
      if((count + threadCount + addInBlock) < queue.length)
          synchronized(notFull){
              notFull.notify();
          }
      return task;
      
  }
  
  /**
   * 
   * @param task task to be added to the FIFO
   * @throws InterruptedException if any thread interrupted the current thread before or while 
   * the current thread was waiting for a notification. The interrupted status of the current thread 
   * is cleared when this exception is thrown.
   */
  public void put(Task task) throws InterruptedException{
      
      // if FIFO is full, block any insertion thread
      if(count == queue.length)
          synchronized(notFull){
              notFull.wait();
          }
      
      // increased because one thread arrived and waiting to enter the critical section
      threadCount++;
      
      // synchronized block that add a task into FIFO and update corresponding cursors
      synchronized(this){
          addInBlock++;
          threadCount--;
          queue[nextIn] = task;
          nextIn = (nextIn + 1) % queue.length;
          count++;
          addInBlock--;
      }
      
      /** 
      * threads waiting to enter critical section are candidates for retrieving tasks from FIFO
      * current number of threads in critical section + potential tasks that will be retrieved from FIFO in the future < current number of tasks in FIFO
      * This must be checked to avoid Null retrieve.
      */
      if(count > (threadDeCount + takeInBlock))
          synchronized(notEmpty){
              notEmpty.notify();
          }
  }
}
